package com.example.demo5.Model;

import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Repository
public class AdminModel {
    Connection con;
    public void insert1(Admindetails admindetails) throws ClassNotFoundException, SQLException {
        String addr = "jdbc:mysql://localhost:3306/electronics";
        String username1= "root";
        String password= "root";
        Class.forName("com.mysql.cj.jdbc.Driver");
        con= DriverManager.getConnection(addr, username1, password);
        String sql = "insert into Admins values (?,?,?,?);";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1,admindetails.id);
        stmt.setString(4,admindetails.username);
        stmt.setString(2,admindetails.Email);
        stmt.setString(3,admindetails.password);
        stmt.execute();
        System.out.println("Records inserted succesfully");
        con.close();
    }
}


