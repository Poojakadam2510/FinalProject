package com.example.demo5.Services;

import com.example.demo5.Model.Userdetails;
import com.example.demo5.Repository.UserRepository1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin("*")

@Service
@Transactional
public class UserService {
    @Autowired
    private final UserRepository1 userRepository1;

    public UserService(UserRepository1 userRepository1) {
        this.userRepository1=userRepository1;
    }

    public void saveMyUser(Userdetails userdetails ) {
        userRepository1.save(userdetails);
    }

    public List<Userdetails> showAllUsers(){
        List<Userdetails> users = new ArrayList<Userdetails>();
        for(Userdetails userdetails : userRepository1.findAll()) {
            users.add(userdetails);
        }

        return users;
    }

 /*  public void deleteMyUser(int id) {
      //  userRepository1.delete(id);
        Userdetails userdetails  = UserRepository1.findById(id);
        UserRepository1.delete(id);
    } */
    public Userdetails findByUsernameAndPassword(String username, String password) {
        return userRepository1.findByUsernameAndPassword(username, password);
    }
}
