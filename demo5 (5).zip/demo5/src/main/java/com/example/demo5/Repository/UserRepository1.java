package com.example.demo5.Repository;

import com.example.demo5.Model.Userdetails;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository1 extends CrudRepository<Userdetails,Integer> {
    public Userdetails findByUsernameAndPassword(String username, String password);
   // public void deleteMyUser(int id);
}
