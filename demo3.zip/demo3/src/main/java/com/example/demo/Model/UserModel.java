package com.example.demo.Model;

import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Repository
public class UserModel {
    Connection con;
    public void insert(Userdetails userdetails) throws ClassNotFoundException, SQLException {
        String addr = "jdbc:mysql://localhost:3306/electronics";
        String username1= "root";
        String password= "root";
        Class.forName("com.mysql.cj.jdbc.Driver");
        con= DriverManager.getConnection(addr, username1, password);
        String sql = "insert into Users values (?,?,?,?);";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setInt(1,userdetails.id);
        stmt.setString(4,userdetails.username);
        stmt.setString(2,userdetails.Email);
        stmt.setString(3,userdetails.password);
        stmt.execute();
        System.out.println("Records inserted succesfully");
        con.close();
    }
}

